<? $conn = new com("ADODB.Connection"); 
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=".db_path.";Uid=;Pwd=;"); ?>