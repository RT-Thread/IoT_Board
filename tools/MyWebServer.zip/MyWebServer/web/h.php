<html>
<head>
<title>First program</title>
</head>
<body>
<?php
  echo "hello, world\n";
?>
</body>
</html>
 
